# CMEE 2019 HPC excercises R code main proforma
# you don't HAVE to use this but it will be very helpful.  If you opt to write everything yourself from scratch please ensure you use EXACTLY the same function and parameter names and beware that you may loose marks if it doesn't work properly because of not using the proforma.
source("ChallengeC.R")
source("ChallengeD.R")
source("ChallengeE.R")
source("ChallengeF.R")



name <- "Sam Turner"
preferred_name <- "Sam"
email <- "sat19@ic.ac.uk"
username <- "sat19"
personal_speciation_rate <- 0.002055 # will be assigned to each person individually in class and should be between 0.002 and 0.007

# Question 1
# return the richness of a community
species_richness <- function(community){
  return(length(unique(community)))
}

# Question 2
# return a vector representing a community of maximum richness for a given size
init_community_max <- function(size){
  return(seq(size))
}

# Question 3
# return a vector representing a community of minimum richness for a given size
init_community_min <- function(size){
  return(rep(1,size))
}

# Question 4
# return two randomly chosen numbers between 1 and a max value, wothout replacement
choose_two <- function(max_value){
  return(sample(1:max_value,2,F))
}

# Question 5
# perform a single neutral simulation step on a community,
# where one individual dies and is replaced by the clone of another.
# returns the new community
neutral_step <- function(community){
  # choose an individual to die and one to reproduce
  choices <- choose_two(length(community))
  # replace the dead individual with a copy of the reproducing individual
  community[choices[1]] <- community[choices[2]]
  return(community)
}

# Question 6
# perform a single generation of the neutral simulation.
# A generation consists of n neutral steps, where:
# if communiyt_size even : n = size / 2
# if communiyt_size odd  : n = floor(size / 2) or n = ceiling(size / 2) with equal probability

neutral_generation <- function(community){
  # if community_size is even, number of steps is size/2
  if (length(community) %% 2 == 0){
    n_steps <- as.integer(length(community)/2)
  }
  #if size is odd, randomly decide whether to use floor or ceiling
  else{
    if (sample(2, 1) == 1){
      n_steps <- as.integer(length(community)/2 + 0.5)
    }
    else{
      n_steps <- as.integer(length(community)/2 - 0.5)
    }
  }

  # run neutral steps for the calculated number of steps
  for (i in 1:n_steps){
    community <- neutral_step(community)

  }
  return(community)
}

# Question 7
# Return a time series of species richnesses for a community, with richness recorded
# after each neutral generation for a specified number of generations.
neutral_time_series <- function(community,duration)  {
  # initialise vector to hold richnesses, and assign first value
  time_series <- rep(NA, duration)
  time_series[[1]] <- species_richness((community))
  
  # calculate the new community and record its richness for the specified number of generations
  for (i in 2:(duration+1)){
    community <- neutral_generation(community)
    time_series[[i]] <- species_richness(community)
  }
  return(time_series)
}

# Question 8
question_8 <- function() {
  # clear graphics
  graphics.off()
  # get time series of richnesses
  richness_time_series <- neutral_time_series(init_community_max(100),200)
  # plot time series
  plot(x = 1:201, y = richness_time_series, pch = 16, cex=0.5,main="Neutral Model - No Speciation", 
       xlab="Generation", ylab="Species Richness")
  
  return("The system will always converge to a mono-dominant state. Species richness can decrease, as extinction is possible (if the last member of species dies) - but richness cannot increase, as the model does not include speciation/migration. The only stable state is therefore mono-dominance, as the rate of extinction and speciation will both be zero.")
}



# Question 9
# Perform a single neutral simulation step on a community, with specified probability of speciation.
# One individual dies and is replaced by a new series with probability equal to the speciation rate.
# Otherwise, it is replaced by a copy of another individual in the community.
# Returns the new community
neutral_step_speciation <- function(community,speciation_rate)  {
  # if the random number (uniform in 0 to 1) is greater than speciation rate, do a normal neutral step
  if (runif(1,0,1) > speciation_rate){
    community <- neutral_step(community)
  }
  # otherwise, replace a ranodmly chosen individual with a new species with identity one larger than the max in the community
  else {
    community[sample(length(community),1)] <- max(community)+1
  }
  return(community)
}

# Question 10
# perform a single generation of the neutral simulation with passed speciation probability.
# A generation consists of n neutral steps, where:
# if communiyt_size even : n = size / 2
# if communiyt_size odd  : n = floor(size / 2) or n = ceiling(size / 2) with equal probability
neutral_generation_speciation <- function(community,speciation_rate)  {
  # if community_size is even, number of steps is size/2
  if (length(community) %% 2 == 0){
    gens <- as.integer(length(community)/2)
  }
  #if size is odd, randomly decide whether to use floor or ceiling
  else{
    if (sample(2, 1) == 1){
      gens <- as.integer(length(community)/2 + 0.5)
    }
    else{
      gens <- as.integer(length(community)/2 - 0.5)
    }
  }
  
  # run neutral steps with speciation for the calculated number of steps
  for (i in 1:gens){
    community <- neutral_step_speciation(community, speciation_rate)
    
  }
  return(community)
}

# Question 11
# Return a time series of species richnesses for a community, with richness recorded
# after each neutral generation for a specified number of generations.
neutral_time_series_speciation <- function(community,speciation_rate,duration)  {
  # initialise vector to hold richnesses, and assign first value
  time_series <- rep(NA,duration)
  time_series[[1]] <- species_richness(community)
  # calculate the new community and record its richness for the specified number of generations
  for (i in 2:(duration+1)){
    community <- neutral_generation_speciation(community,speciation_rate)
    time_series[[i]] <- species_richness(community)
  }
  return(time_series)
}

# Question 12
question_12 <- function()  {
  
  # clear graphics
  graphics.off()
  
  # get time series for minimum and maximum richness communities
  time_series_min <- neutral_time_series_speciation(init_community_min(100), 0.1, 200)
  time_series_max <- neutral_time_series_speciation(init_community_max(100), 0.1, 200)
  
  # plot min richness time series
  plot(x = 1:201, y = time_series_min,main="Neutral Model - No Speciation", 
       xlab="Generation", ylab="Species Richness", type = 'l', col="blue", ylim = c(1,max(time_series_max)))
  # add max richness time series
  lines(x=1:201, y = time_series_max, col="red")
  # add legend
  legend(x = "topright", legend=c("Minimum Richness", "Maximum Richness"),
         col=c("blue", "red"),lty=1, cex=0.8)
  return("Regardless of starting conditions, species richness converges to fluctuate around the same non-zero value. Dynamic equilibrium between speciation and extinction happens at a richness >1, as speciation rate is greater than zero. However, convergence of richnesses does not imply complete loss of memory of starting conditions, as richness is an is not a sufficient statistic for the community. As such, it is possible that eg. the variance of species richness differs for the two simulations after mean richness has converged. These results are therefore insufficient to fully demonstrate that divergent communities converge.")
}

# Question 13
# Returns a species abundance vector for a community
species_abundance <- function(community)  {
  return(as.vector(sort(table(community),decreasing = T)))
}

# Question 14
# finds the octave frequencies of an abundance vector
octaves <- function(abundance_vector) {
  return(tabulate(floor(1+log2(abundance_vector))))
}

# Question 15
# adds vectors of differing length, with missing entries in shorter vector treated as zeroes
sum_vect <- function(x, y) {
  # get both lengths
  l_y <- length(y)
  l_x <- length(x)
  
  # if y vector is longer
  if (l_y >= l_x){
    # use vector arithmatic to add y to to x vector with zeros added to make it the same length
    return( y + c(x, rep(0,l_y - l_x)) ) 
  }
  # otherwise, call sum_vect with x and y switched
  else{
    sum_vect(y,x)
  }
}

# Question 16 
question_16 <- function()  {
  # clear existing graphics
  graphics.off()
  
  # initialise min richness and max richness communities
  min_community <- init_community_min(100) 
  max_community <- init_community_max(100)
  
  # initialise octave lists. Lists used to allow variable length octave vectors.
  # Using array / matrix did not give significant speed advantage.
  min_octaves = list()
  max_octaves = list()
  
  
  # loop over all generations
  for (g in 1:2200){
    # calculate new communities
    min_community <- neutral_generation_speciation(min_community,0.1)
    max_community <- neutral_generation_speciation(max_community,0.1)
    # record octave every 20 generations after the burn in period
    if (g > 199 & g %% 20 == 0){
      min_octaves[[length(min_octaves)+1]] <- octaves(species_abundance(min_community))
      max_octaves[[length(min_octaves)+1]] <- octaves(species_abundance(max_community))
    }
    
  }
  
  # sum octaves
  min_sum <- c()
  max_sum <- c()
  for (l in min_octaves){
      min_sum <- sum_vect(min_sum,l)
      max_sum <- sum_vect(max_sum,l)
  }
  
  # find mean octaves
  min_means <- min_sum / length(min_octaves)
  max_means <- max_sum / length(max_octaves)
  
  # make both vectors of equal length for better bar chart comparison
  longest_length <- max(length(min_means), length(max_means))
  
  min_means <- sum_vect(min_means,rep(0,longest_length))
  max_means <- sum_vect(max_means,rep(0,longest_length))
  

  # produce vector of bar names
  x_names <- c("1")
  for (i in 2:longest_length-1){
    x_names <- c(x_names, paste(as.character(2**i), "-" ,as.character(2**(i+1) - 1) ))
  }
  
  # produce array for 'beside' bar chart
  both <- rbind(min_means, max_means)
  
  # plot bar chart
  barplot(both, main=paste("Octave distributions"), 
          xlab="Octave", col=c("darkblue","red"),
          ylab="Frequency", ylim = c(0,10), legend = c("Minimum Initial Richness", "Maximum Initial Richness"),
          beside=TRUE, names.arg = x_names,cex.names=0.7)
  
  return("No, the initial conditions do not affect the final octave distribution. This is probably because there is only one stable dynamic equlibrium state for this system, which all starting conditions converge towards. It is possible (but appears unlikely) that initial conditions do cause different stable states to be reached, but that this difference is not captured by the octave distribution.")
}

# Question 17
# Code to run neutral model with speciation on cluster.
cluster_run <- function(speciation_rate, size, wall_time, interval_rich, interval_oct, burn_in_generations, output_file_name)  {
  # initialise minimum richness community
  community <- init_community_min(size)
  
  # take start time
  t <- proc.time()[[3]]
  
  gen <- 1
  
  # make lists to store richnesses and octaves
  richnesses <- list()
  octaves_list <- list()
  
  # while the elapsed time is less than the passed wall time
  while ((proc.time()[[3]] - t) < wall_time*60) {
    
    
    # record the richness every interval_rich gens, if burn in is passed
    if ((gen) %% interval_rich == 0 & gen < burn_in_generations){
      richnesses[[as.character(gen)]] <- species_richness(community)
    }
    # record the octave every interval_oct gens
    if ((gen) %% interval_oct == 0) {
       octaves_list[[as.character(gen)]] <- octaves(species_abundance(community))
    }
    # calculate new community
    community <- neutral_generation_speciation(community, speciation_rate)
    gen <- gen + 1
    
  }
  
  # save result in outoout list
  output_list <- list("richnesses" = richnesses, "octaves" = octaves_list, "final_community" = community, "time_used" = proc.time()[[3]] - t,
                      "speciation_rate" = speciation_rate,  "size" = size, "wall_time" = wall_time/60,"interval_rich" = interval_rich,
                      "interval_oct"=interval_oct, "burn_in" = burn_in_generations)
  
  save(output_list, file = output_file_name)
  return()
}

# Questions 18 and 19 involve writing code elsewhere to run your simulations on the cluster

# Question 20 
process_cluster_results <- function()  {
  graphics.off()
  
  
  # get files which are simulation outputs
  files <- list.files(path = "results/")
  files <- files[grepl("^simulation_out",files)]
  
  # make a list to count octave sums and number of recorded octaves for each community size
  oct_sums = list("500"=c(),"1000"=c(),"2500"=c(),"5000"=c())
  oct_counter = list("500"=0,"1000"=0,"2500"=0,"5000"=0)
  
  # keep trac of longest octave vector
  max_length = 0
  
  # for each simulation output file
  for (f in files){
    # load results, extract size and octaves
    load(paste0("results/",f))
    size = as.character(output_list$size)
    octaves = output_list$octaves
    # remove octaves that are during the burn in
    octaves = octaves[as.numeric(names(octaves)) > as.numeric(size) * 8]

    # add the remaining octaves to the octave sum entry for the correct community size
    for (octave in octaves){
      oct_sums[[size]] = sum_vect(oct_sums[[size]], octave)
      max_length = max(max_length, length(octave))
    }
    # add the number of octaves in that simulation run to the octaves counter
    oct_counter[[size]] = oct_counter[[size]] + length(octaves)
  }
  
  # calculate mean octave for each community size
  oct_means = list()
  for (size in names(oct_sums)){
    oct_means[[size]] = oct_sums[[size]] / oct_counter[[size]]
  }
  
  # make all mean octaves the same length by adding zeroes to shorter ones (for comparable bar plots)
  for (size in names(oct_means)) {
    oct_means[[size]] <- sum_vect(oct_means[[size]], rep(0,max_length) )
  }
  
  # set up plot window
  par(mfrow=c(2,2), oma=c(0,0,2,0))
  
  # plot data for each size
  for (size in names(oct_means)){
    barplot(oct_means[[size]], names.arg = as.character(1:length(oct_means[[size]])),cex.names=0.7)
    title(main = paste("Size:",size), x = "Octave", y = "Frequency")
  }
  
  mtext("Cluster Run Octaves", line=0, side=3, outer=TRUE, cex=1.2)
  
  return(oct_means)
}


########################################
# Q20 repeated, called in Challenge D #
########################################

# I have repeated the function because I want to return the number of octaves also.
# Normally, I would have a boolean arguement determining what to return in a case like this
# But I have copied and modified the function so the original function can fulfill
#   the assessment brief. 

process_cluster_results_challenge_D <- function()  {
  # clear any existing graphs and plot your graph within the R window
  combined_results <- list() #create your list output here to return
  
  # get files which are simulation outputs
  files <- list.files(path = "results/")
  files <- files[grepl("^simulation_out",files)]
  
  oct_sums = list("500"=c(),"1000"=c(),"2500"=c(),"5000"=c())
  oct_counter = list("500"=0,"1000"=0,"2500"=0,"5000"=0)
  max_length = 0
  
  for (f in files){
    load(paste0("results/",f))
    size = as.character(output_list$size)
    octaves = output_list$octaves
    octaves = octaves[as.numeric(names(octaves)) > as.numeric(size) * 8]
    
    for (octave in octaves){
      oct_sums[[size]] = sum_vect(oct_sums[[size]], octave)
      max_length = max( max_length, length(octave))
    }
    
    oct_counter[[size]] = oct_counter[[size]] + length(octaves)
    #max_length = max(max_length, max(unlist(lapply(octaves, length)))
    
  }
  
  oct_means = list()
  for (size in names(oct_sums)){
    oct_means[[size]] = oct_sums[[size]] / oct_counter[[size]]
  }
  
  
  for (size in names(oct_means)) {
    oct_means[[size]] <- sum_vect(oct_means[[size]], rep(0,max_length) )
  }

  return(data.frame(means = oct_means, counts = oct_counter))
}




# Question 21
# Text answer to fractal question
question_21 <- function()  {
  return(list(dimension = "log(8) / log(3)", explanation = "Need 8 copies of a self similar section to produce a shape which is 3 times wider. So 3^d = 8, solve for d."))
}

# Question 22
# Text answer to fractal question
question_22 <- function()  {
  return(list(dimension = "log(20) / log(3)", explanation = "Need 20 copies of a self similar section to produce a shape which is 3 times wider. So 3^d = 20, solve for d."))
}

# Question 23
chaos_game <- function()  {
  # clear existing graphics
  graphics.off()
  # list of corner points
  points = list(A = c(0,0), B = c(3,4), C = c(4,1))
  # variable point
  X = c(0,0)
  # number of chaos game steps
  moves = 100000
  # initialise array of coordinates
  to_plot = array(data = NA, dim = c(moves,2))
  # add first coordinate
  to_plot[1,] = X
  # for each move...
  for (i in 2:moves){
    # update position of X to mean of previous X and randomly chosen corner point
    X = (X + points[[sample(1:3,1)]]) / 2
    to_plot[i,] = X
  }
  # plot the array of coordinates
  plot(x = to_plot[,1], y = to_plot[,2], pch = 16, cex = 0.2, asp = 1, xaxt = "n",
       yaxt = "n", xlim = c(-0.5, 4.5), ylim = c(-0.5, 4.5), main = "Slanted Sierpinksy Gasket",
       xlab = NA, ylab = NA)
  return("This algorithm produced points whose distribution (in the limit) is Sierpinsky's Gasket. As more points are added, the points follow the distribution more closely.")
}

# Question 24
# Draw line woith specified start position, direction and length
# Returns the coordinates of the end of the line
turtle <- function(start_position, direction, length)  {
  # find end position
  end_position <- start_position + c(cos(direction),sin(direction))*length
  # plot line from start position to end position
  lines(rbind(start_position,end_position))
  
  return(end_position) # you should return your endpoint here.
}

# Question 25
# Draw two lines. The first has specified start position, length and direction
# The second creates ab 'elbow' as it has:
#   start pos = end position of the first line
#   direction = first_direction - pi/4
#   length    = first_length * 0.95
elbow <- function(start_position, direction, length)  {
  # draw first line and record end position
  end_position <- turtle(start_position, direction, length)
  # draw second line
  turtle(end_position, direction-pi/4, length*0.95)
}

# Question 26
# Draws a spiral by recursively calling itself, drawing a line with direction rotated by pi/4 and
# length decreased by 5% each time. Recursion terminates when length crosses a minimum threshold. 
spiral <- function(start_position, direction, length)  {
  # draw line and record end position
  end_pos <- turtle(start_position, direction, length)
  # if length threshold not passed
  if (length > 0.1){
    # call self, drawing line rotated by pi/4 clockwise and length reduced by 5%
    spiral(end_pos, direction-pi/4, length*0.95)
  }
  return("A spiral is drawn, as the turtle function is recursively called with the same change in line angle but reducing line length. The error occurs as the recursion had no way to terminate, so the function keeps getting called, opening new frames on the stack until its limit is reached")
}

# Question 27
# sets up plot and calls spiral to produce spiral plot
draw_spiral <- function()  {
  # clear existing plots
  graphics.off()
  
  # set up plot
  plot.new()
  plot.window(xlim = c(0,2.2),ylim = c(-0.5,2), asp = 1)
  axis(1, labels = F, tick = F)
  axis(2, labels = F, tick = F)
  title(main = "Spiral", line = -2)
  
  # call spiral and capture function text output
  text_output <- spiral(c(0,0), pi/2, 1);
  
  return(text_output)
}

# Question 28
# Draws a tree by recursively calling self twice, drawing two lines rotating clockwise and anticlockwise by pi/4
# and with length decresed by 35% each call
tree <- function(start_position, direction, length)  {
  # draw line and record end position
  end_pos <- turtle(start_position, direction, length)
  # if length threshold not passed
  if (length > 0.01){
    # call self to draw line rotated clockwise
    tree(end_pos, direction-pi/4, length*0.65)
    # call self to draw line rotated anticlockwise 
    tree(end_pos, direction+pi/4, length*0.65)
  }
}

# Sets up plot and calls tree function to draw tree
draw_tree <- function()  {
  # clear existing graphics
  graphics.off()
  # set up plot
  plot.new()
  plot.window(xlim = c(-1.5,1.5),ylim = c(-0,2.8), asp = 1)
  axis(1, labels = F, tick = F)
  axis(2, labels = F, tick = F)
  title(main = "Tree", line = -2)
  
  # draw tree
  tree(c(0,0), pi/2, 1)
}

# Question 29
# Draws a fern by recursively calling self twice, drawing two lines: one not rotated and with length decreased by 13%,
# the other rotated anticlockwise by pi/4 and with length decreased by 62%

fern <- function(start_position, direction, length)  {
  # draw line and record end position
  end_pos <- turtle(start_position, direction, length)
  # check if length threshold passed
  if (length > 0.01){
    # call self to draw line with same direction and 13% reduced length
    fern(end_pos, direction, length*0.87)
    # call self to draw line with direction rotated by pi/4 clockwise and length reduced by 62%
    fern(end_pos, direction+pi/4, length*0.38)
  }
}

# Sets up plot and calls fern function to draw fern
draw_fern <- function()  {
  # clear existing graphics
  graphics.off()
  
  # set up plot
  plot.new()
  plot.window(xlim = c(-2,2),ylim = c(-0.5,9), asp = 1)
  axis(1, labels = F, tick = F)
  axis(2, labels = F, tick = F)
  title(main = "Fern", line = -2)
  
  # draw fern
  fern(c(0,0), pi/2, 1)
}

# Question 30
# Draws a fern by recursively calling self twice, drawing two lines: one not rotated and with length decreased by 13%,
# the other rotated anticlockwise by pi/4 and with length decreased by 62%. Each call to draw a line in the same 
# direction reflects the direction in the vertical axis to produce 'leaves' on each side.
fern2 <- function(start_position, direction, length,dir)  {
  # draw line and record end position
  end_pos <- turtle(start_position, direction, length)
  # check if length threshold passed
  if (length > 0.005){
    # call self to draw line with same direction and length reduced by 13%, flipping dir variable
    fern2(end_pos, direction, length*0.87,dir*-1)
    # call self to draw line with rotated and reflected direction and length reduced by 62%
    fern2(end_pos, direction+dir*pi/4, length*0.38,dir)
    
  }
}

# Sets up plot and calls fern2 function to draw fern
draw_fern2 <- function()  {
  # clear existing graphics
  graphics.off()

  # set up plot
  plot.new()
  plot.window(xlim = c(-2,2),ylim = c(-0.5,9), asp = 1)
  axis(1, labels = F, tick = F)
  axis(2, labels = F, tick = F)
  title(main = "Fern 2", line = -2)
  
  # draw fern
  fern2(c(0,0), pi/2, 1,1)
}

# Challenge questions - these are optional, substantially harder, and a maximum of 16% is available for doing them.  

# Challenges A and B helper function
# Runs neutral simulations for a given community size and number of generations, returning the
# mean and two-tailed 97.2% confidence interval
mean_conf <- function(community, repeats, gens){
  
  # initialise array to store richnesses
  richnesses <- array(dim = c(repeats,gens))
  
  # for each replicate
  for (replicate in 1:repeats){
    
    # initialise community for simulation
    community_rep <- community
    
    # write first richness
    richnesses[replicate,1] <- species_richness(community_rep)

    # simulate neutral generations and write richnesses to array
    for (g in 2:gens){
      community_rep <- neutral_generation_speciation(community_rep,0.1)

      richnesses[replicate,g] <- species_richness(community_rep)
    }
  }
  
  # array to store means and confidence intervals for species richness each generation
  mean_and_conf <- array(dim = c(3,gens))

  # for each generation of the simulation
  for (g in 1:gens){
    
    # sort the richnesses
    richnesses[,g] <- sort(richnesses[,g])

    # bottom of the 97.2% confiidence interval is the value in the sorted list at index 1.4% from the bottom
    # I use floor and ceiling to give a conservative estimate of the confidence interval
    bottom_index <- floor(repeats*0.014)
    # top of the 97.2% confiidence interval is the value in the sorted list at index 1.4% from the top
    top_index <- ceiling(repeats*0.986)
    
    # means and interval bounds
    mymean <- as.numeric(mean(richnesses[,g]))
    mybottom <- as.numeric(richnesses[bottom_index,g])
    mytop <- as.numeric(richnesses[top_index,g])
    
    # save means and interval bound for this generation
    mean_and_conf[1,g] <- mymean
    mean_and_conf[2,g] <- mybottom
    mean_and_conf[3,g] <- mytop
  }
  return(mean_and_conf)
}


# Challenge question A
# Plots mean and 97.2% confidence interval for size 100 community for 100 generations
Challenge_A <- function() {
  
  # clear graphics
  graphics.off()
  
  # set parameters
  repeats = 290
  gens = 100
  size = 100
  
  # get arrays of means and confidence intervals for min and max richness communities
  mean_and_conf_min <- mean_conf(init_community_min(size),repeats,gens)
  mean_and_conf_max <- mean_conf(init_community_max(size),repeats,gens)
  
  # plot max richness mean
  plot(x = 1:gens, y = mean_and_conf_min[1,],main="Challenge A: Species Richness Convergence woth CIs", 
       xlab="Generation", ylab="Species Richness", type = 'l', col="red", ylim = c(1,size))
  # plot max richness CI
  lines(x=1:gens, y = mean_and_conf_min[2,], col="red",lty = 2)
  lines(x=1:gens, y = mean_and_conf_min[3,], col="red",lty = 2)

  # plot min richness mean
  lines(x = 1:gens, y = mean_and_conf_max[1,], col="blue")
  # plot max richness CI
  lines(x=1:gens, y = mean_and_conf_max[2,], col="blue",lty = 2)
  lines(x=1:gens, y = mean_and_conf_max[3,], col="blue",lty = 2)

  # draw line at 50 generations to show approximately where dynamic eqm is met, according to the speices richness summary statistic
  abline(v = 50, col = "black", lty = "dashed")
  text("Dynamic Equilibrium",x=47.5, y = 70, col= "black" , srt = 90)
  
  # draw legend
  legend(x="topright", legend=c("Minimum initial richness", "Maximum initial richness"),
         col=c("red", "blue"),lty=1, cex=0.8)
  
}



# Challenge question B
# Plots mean richness for communities of size 100, with varying intiial richness, for 60 generations
Challenge_B <- function() {
  # clear graphics
  graphics.off()
  
  # set parameters
  repeats <- 200
  gens <- 60
  size <- 100
  
  # vector initial richnesses
  initial_richnesses <- c(1,2,5,10,20,50,100)
  # list of initial communities
  initial_communities <- list()
  
  # create intitial communities
  for (i in 1:length(initial_richnesses)){
    n_species <- initial_richnesses[[i]]
    initial_communities[[i]] <- rep(1:n_species, each = 100/n_species)
  }
  
  # list to store time series of mean richnesses for each initial richness
  richness_serieses <- list()
  
  # calculate and store mean richness time series for each initial richness
  for (i in 1:length(initial_communities)){
    richness_serieses[[i]]<-mean_conf(initial_communities[[i]], repeats,gens)[1,]
  }

  colours <- c("#1b9e77","#d95f02","#7570b3","#e7298a","#66a61e","#e6ab02","#a6761d")

  # initialise plot
  plot(x = c(), y=c(),main="Challenge B: Species Richness Convergence", xlab="Generation", ylab="Species Richness", ylim = c(1,size), xlim = c(1,gens))
  
  # plot each richness time series
  for (i in 1:length(richness_serieses)){
    lines(x = 1:gens, y = richness_serieses[[i]], col = colours[[i]])
  }
  
  # add legend
  legend(x="topright",legend=initial_richnesses,
         col=colours,lty=1, cex=0.8, pt.lwd = 2, title = "Initial Richness")
  
}

# Challenge question C
# Plots richness time series for cluster simulations of communities of varying size during their burn in
Challenge_C <- function() {
  # clear graphics
  graphics.off()
  # run sourced function.
  challenge_C_external()
  return()
}

# Challenge question D
# Compares coalescent simulation octaves to full simulation octaves, demonstrating their equivalence
Challenge_D <- function() {
  graphics.off()
  # clear any existing graphs and plot your graph within the R window
  challenge_D_external()
  return("The compute time for the coalescent method is much faster, as we only track the lineages which end up in the final community (not wasting compute time on extinct lineages). The full simulation took 1200 CPU hours. Here, we calculate 0.1% of the number of octaves in about 1 minute. So the coalescent is about 1200 / (1000*(1/60)) = 72 times faster.")
}

# Challenge question E
# Compares time to draw ferns with varying length thresholds
Challenge_E <- function() {
  graphics.off()
  # clear any existing graphs and plot your graph within the R window
  chaos_game_challenge()
  return("First 200 moves are shown in red. Even if first point is outside of the fractal, points are quickly very near or within the fractal shape bounds. Also clear that there are many (in fact, infinite) combinations of vertices and distance proportions which produce fractals - although there are many which produce a diffuse cloud of points.")
}

# Challenge question F
Challenge_F <- function() {
  graphics.off()
  # clear any existing graphs and plot your graph within the R window
  time_data()
  return("As the length threshold decreases, the intricacy of the image increases, as finer and finer branches (of shorter length) are drawn. This results in a straight line relationship between length threshold and compute time on the log-log plot (= polynomial relationship in linear space), as the number of coordinates calculated and lines drawn increases with decreasing length threshold.")
}

# Challenge question G should be written in a separate file that has no dependencies on any functions here.


