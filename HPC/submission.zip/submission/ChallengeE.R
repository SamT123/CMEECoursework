chaos_game_challenge <- function()  {
  # for each interesting choas game, specify:
  # position of vertices to move towards, and the proportion of the randomly selected coordinate
  # to use when calculating new position
  
  points_gasket = list(A = c(0,0), B = c(10,0), C = c(5,10*sin(pi/3)))
  proportion_gasket = 1/2
  
  points_gasket_third = list(A = c(0,0), B = c(10,0), C = c(5,10*sin(pi/3)))
  proportion_gasket_third = 2/3
  
  points_vicsek = list(A = c(0,0), B = c(10,0), C = c(0,10), D = c(10,10), E = c(5,5))
  proportion_vicsek = 2/3
  
  points_carpet <- list(A = c(0,0), B = c(10,0), C = c(0,10), D = c(10,10), E = c(0,5), I = c(5,0), G = c(10,5), H = c(5,10))
  proportion_carpet = 2/3
  
  points_pent <- list(A = c(10.0,5.0), B = c(6.5,.2), C = c(1.0,2.1), D = c(1.0,7.9), E = c(6.5,9.8))
  proportion_pent = 1 / ((1+sqrt(5))/2)

  
  points_hex <- list(A = c(7.5,.7), B = c(2.5,.7), C = c(0,5.0), D = c(2.5,9.3), E = c(10.0,5.0),G=c(7.5,9.3))
  proportion_hex = 2/3

  # sotore all of these in lists
  points_list = list(points_gasket, points_gasket_third, points_vicsek, points_carpet, points_pent, points_hex)
  proportions_list = list(proportion_gasket, proportion_gasket_third, proportion_vicsek, proportion_carpet,proportion_pent, proportion_hex)
  titles_list <- list("Sierpinski triangle, r = 1/2", "Sierpinski triangle, r = 2/3", "Vicsek fractal", "Sierpinski carpet", "Pentaflake", "Hexaflake")
  
  # number of moves to complete, and number to highlight in red
  moves = 10000
  highlights = moves / 500
 
  # set up plot window
  par(mfrow=c(2,3), mai = c(0.1,0.1,0.2,0.1))
  
  # for each plot
  for (j in 1:(length(points_list))){
    # get vertices and proportion
    points = points_list[[j]]
    proportion = proportions_list[[j]]
    # set initial X position
    X = c(5,5)
    
    # initialise array to store points
    to_plot = array(data = NA, dim = c(moves,2))
    to_plot[1,] = X
    
    # calculate and store subsequent coordinates
    for (i in 2:moves){
      X = (1-proportion) * X + proportion * points[[sample(1:length(points),1)]]
      to_plot[i,] = X
    }
    
    # add columns for point colour and size
    to_plot <- cbind(to_plot, c(rep("red", highlights), rep("black", dim(to_plot)[[1]]-highlights)))
    to_plot <- cbind(to_plot, c(rep(0.5, highlights), rep(0.2, dim(to_plot)[[1]]-highlights)))
    
    # make subplot
    plot(x = to_plot[,1], y = to_plot[,2], col = to_plot[,3], pch = 16, cex = as.numeric(to_plot[,4]),
         xlim = c(0,10), ylim= c(0,10),asp = 1,xlab=NA, ylab=NA, xaxt = "n", yaxt="n",
         main = titles_list[[j]])
  }
  
  return("First 200 moves are shown in red. Can see that points quickly match the fractal pattern. Also clear that there are many (in fact, infinite) combinations of vertices and distance to travel which produce fractals - although there are manny which produce a diffuse cloud of points.")
}

