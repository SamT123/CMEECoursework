
challenge_C_external <- function(){
  
  # get files which are simulation outputs
  files <- list.files(path = "results/")
  files <- files[grepl("^simulation_out",files)]
  
  # lists to store species richnesses and number of richness data points
  richnesses = list("500"=c(),"1000"=c(),"2500"=c(),"5000"=c())
  counter = list("500"=c(),"1000"=c(),"2500"=c(),"5000"=c())
  
  # for each simulation output file:
  for (f in files){
    
    # load rda
    load(paste0("results/",f))
    
    # get size and richnesses list
    size = as.character(output_list$size)
    curr_richnesses = output_list$richnesses
    
    # add richnesses to correct vector in richnesses list
    richnesses[[size]] <- sum_vect(richnesses[[size]],unlist(curr_richnesses))
    
    # keep track of how many simulations produced a richness for a particular generation
    counter[[size]] <- sum_vect(counter[[size]],rep(1,length(curr_richnesses)))
  }
  
  # calculate the mean richness at each generation
  mean_richnesses = list()
  for (size in names(richnesses)){
    mean_richnesses[[size]] = richnesses[[size]] / counter[[size]]
  }
  
  # set up plot
  par(mfrow = c(2,2), mai = c(.5,.5,.5,.5), oma=c(2,2,2,0))
  
  # number of generations to plot
  plot_number = 4000
  yticks <-list("500" = c(0,2,4,6,8), "1000" = c(0,4,8,12,16), "2500" = c(0,10,20,30,40), "5000" = c(0,20,40,60,80))
  
  # for each size, plot richnesses scatter
  for (size in names(mean_richnesses)){
    tix <- yticks[[size]]
    plot_range = 1:plot_number
    plot(plot_range,mean_richnesses[[size]][plot_range], pch = 20, cex = 0.5,
         main = paste("Size:",size), xlab = "Generation", ylab = "Richness" , yaxt="n", ylim = c(min(tix), max(tix)))
    
    axis(2, at=tix, labels = as.character(tix))
  }
  
  # axis labels
  
  mtext('Generation', side = 1, outer = T, line = 0.2, cex=1.2)
  mtext('Mean Richness', side = 2, outer = T, line = 0.2, cex=1.2)
  mtext("Mean Species Richness vs Generation", line=0, side=3, outer=TRUE, cex=1.2)
  
  return()

}