

challenge_D_external <- function(){
  
  # Function with code which must be repeated until final abundance vector is achieved
  # I have used global varibales as an implementation with normal recursion
  # was exceeding C stack usage for comunity size > 2350
  coalescence <- function(){
    # choose random index and random number
    j <<- sample.int(length(lineages),1)
    randnum <<- runif(1)

    # if random number < threshold, add number at random index in lineages to the abundances vector
    if (randnum < theta / (theta + N - 1)){
      abundances <<- c(abundances, lineages[[j]])
      
    
    } else if (randnum >= theta / (theta + N -1)){
      # otherwise, add two random entries in lineages together
      i <<- sample(rep((1:length(lineages))[-j],2),1)
      lineages[i] <<- lineages[i] + lineages[j]
      
    }
    
    # remove the item at the random index j and update length variable N
    lineages <<- lineages[-j]
    N <<- N - 1
    
    return()
    
  }
  
  # run a coalescent simulation for a passed community size
  run_coalescent <- function(this_J){
    
    # set parameters
    J <<- this_J
    v <<- 0.002055
    
    # intialise vectors
    lineages <<- rep(1, J)
    abundances <<- c()
    N <<- J
    theta <<- v*(J-1)/(1-v)
    
    # run code to produce abundance vector while liniages length > 1
    while (N > 1){
      coalescence()
    }
    
    # add last member of lineages to abundances and return abundances
    return(c(abundances,lineages))
  }
  
  
  # get the octave results of the full simulation, and the number of octaves for each size
  cat("Processing full cluster results\n")
  full_sim_results <- process_cluster_results_challenge_D()
  
  # lists to keep track of the octave and richness sums and counts for the coalescent model
  coal_octave_sums = list("500"=c(),"1000"=c(),"2500"=c(),"5000"=c())
  coal_richnesses = list("500"=c(),"1000"=c(),"2500"=c(),"5000"=c())
  coal_octave_counts = list("500"=full_sim_results$counts.500[1],"1000"=full_sim_results$counts.1000[1],"2500"=full_sim_results$counts.2500[1],"5000"=full_sim_results$counts.5000[1])
  
  # not going to collect the same number of octaves as the original run (would take too long)
  # set proportion to collect 1/proportion number of octaves relative to fuill cluster run
  proportion = 1000
  
  cat("Calculating coalescent octaves\n")
  # time how long coalescent simulation takes to compare CPU hours
  start = proc.time()[3]
  
  # for each community size
  for (size in names(coal_octave_counts)){
    
    # collect max(full_sim_number * 1/proportion, 100)  octaves
    todo = floor((coal_octave_counts[[size]])/proportion)
    todo = max(todo, 100)
    
    # print how many octaves there are to do for that size
    cat(size,"\n")
    cat("\t",todo, " to do!\n")
    
    # for each repeat
    for (r in 1:todo){
      # calculate and add the octave to the sum of octaves for that community size
      coal_abun <- sort(run_coalescent(as.numeric(size)), decreasing = TRUE)
      coal_octave_sums[[size]] <- sum_vect(coal_octave_sums[[size]], octaves(coal_abun))
      coal_richnesses[[size]] <- c(coal_richnesses[[size]], length(coal_abun))
      
      # print progress every 1000 octaves
      if (as.numeric(r) %% 1000 == 0){
        cat("\tTime = ",  as.character(proc.time()[3] - start))
        cat("\n\t",as.character((as.numeric(r) / todo)*100), "%\n")
        cat("\t",r, " / ", todo,"\n")
      }
    }
    # convert the sum into a mean
    coal_octave_sums[[size]] <- coal_octave_sums[[size]] / todo
  }
  # calculate total time elapsed
  tottime <- proc.time()[3] - start
  print(tottime)
  
  # list of octave means from full simulation
  full_octave_sums <- list("500" = full_sim_results$means.500,"1000" = full_sim_results$means.1000,
                           "2500" = full_sim_results$means.2500,"5000" = full_sim_results$means.5000)
  
  # coalescent and full simulation results into simgle list
  octave_distributions <- list(coal_octave_sums, full_octave_sums)

  
  # set up plot window
  plot.new()
  #layout(matrix(c(1,2,3,4), nrow = 2, ncol = 2, byrow = TRUE), heights = c(3,3), widths = c(12,12))
  par(mfrow = c(2,2), oma = c(1,1,2,0))
  # for each size
  for (size in 1:4){
  
    # get vector of coalescent and full sim octave means
    coal <- octave_distributions[[1]][[size]]
    full <- octave_distributions[[2]][[size]]
    
    # make all octaves the same length
    max_length <- as.integer(max(length(coal), length(full)))
    
    coal <- sum_vect(coal, rep(0,max_length) )
    full <- sum_vect(full, rep(0,max_length) )

    
    # make side by side bar plot
    counts <- rbind(coal, full)
    
    barplot(counts, main=paste("Size", names(octave_distributions[[1]])[[size]]),
            xlab="Octave", col=c("darkblue","red"),
            ylab="Frequency", #legend = c("Coalescent", "Full Sim"),
            beside=TRUE, names.arg = as.character(1:max_length) ,cex.names=0.7)
    legend("topright", 
           legend = c("Coalescent", "Full Sim"), 
           fill = c("darkblue","red"),
           cex = 0.7)
  }
  
  mtext("Challenge D: Coalescent vs Full Simulation", line=0, side=3, outer=TRUE, cex=1.2)
  

  return()
}
