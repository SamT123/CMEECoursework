


# Need to be able to vary threshold parameter, so functions rewritten #


# Question 30
# main fern2 function with added threshold parameter
fern2_challenge <- function(start_position, direction, length, dir, threshold)  {
  end_pos <- turtle(start_position, direction, length)
  if (length > threshold){
    fern2_challenge(end_pos, direction, length*0.87,dir*-1,threshold)
    fern2_challenge(end_pos, direction+dir*pi/4, length*0.38,dir,threshold)
    
  }
}

# draw varibale threshold fern2
draw_fern2_challenge <- function(threshold)  {
  plot.new()
  plot.window(xlim = c(-2,2),ylim = c(-0.5,9), asp = 1)
  axis(1, labels = F, tick = F)
  axis(2, labels = F, tick = F)
  fern2_challenge(c(0,0), pi/2, 1, 1, threshold)
}

####################
# Variable colours #
####################

# turtle function drawing line in specified colour
turtle_col <- function(start_position, direction, length,this_col)  {
  xs = c(start_position[1],start_position[1]+cos(direction)*length)
  ys = c(start_position[2],start_position[2]+sin(direction)*length)
  lines(xs,ys, type="l", col = this_col)
  return(c(xs[2],ys[2])) # you should return your endpoint here.
}

# fern2 function with ability to vary threhold, and calling tutle_col function to draw line i colour depending on line length
fern2_challenge_col <- function(start_position, direction, length, dir, threshold)  {
  col <- "dark green"
  if (length < 0.05){ col <- "green"}
  if (length < 0.04){ col <- "green"}
  if (length < 0.01){ col <- "red"}
  if (length < 0.005){ col <- "gold"}
  
  end_pos <- turtle_col(start_position, direction, length,col)
  
  if (length > threshold){
    fern2_challenge_col(end_pos, direction, length*0.9,dir*-1,threshold)
    fern2_challenge_col(end_pos, direction+dir*pi/4, length*0.38,dir,threshold)
    
  }
}

# calls fern2_challenge_col to draw 4-headed tree
fern2_pretty <- function(start_position, direction, length, dir, threshold)  {
  end_pos <- c(0,0)
  if (length > threshold){
    fern2_challenge_col(end_pos, direction, length*0.8,dir,threshold)
    fern2_challenge_col(end_pos, direction+dir*pi/2, length*0.8,dir,threshold)
    fern2_challenge_col(end_pos, direction-dir*pi/2, length*0.8,dir,threshold)
    fern2_challenge_col(end_pos, direction+dir*pi, length*0.8,dir,threshold)
  }
}

# sets up window and clals fern2_pretty to draw a pretty fern
draw_fern2_pretty <- function(threshold)  {
  plot.new()
  plot.window(xlim = c(-3,3),ylim = c(-12,12), asp = 1)
  axis(1, labels = F, tick = F)
  axis(2, labels = F, tick = F)
  fern2_pretty(c(0,0), pi/4, 1, 1, threshold)
}


################
# Produce plot #
################

# times calls to fern2_challenge to demonstrate the time effect of decreasing length threshold (to draw more lines)
time_data <- function(){
  
  # set up plot window
  layout(matrix(c(1,2,3,4,5,6,7,7,7,7), nrow = 2, ncol = 5, byrow = FALSE))
  par(mai = c(0.1,0.1,0.1,0.1))
  
  # number of time data points to collect
  n <- 5
  # array to store times
  times = array( data = NA, dim = c(n,2) )
  # log distributed length thresholds
  threshs <- 10^((-(n):-1)/2)
  # for each time data point
  for (i in 1:n){
    # start timing
    t_start = proc.time()[[3]]
    # draw fern
    draw_fern2_challenge(threshs[i])
    #stop timing
    t_elapsed = proc.time()[[3]] - t_start
    
    # get well formatted threshold string
    threshold_string <- paste0("10^", as.character( (((-(n):-1)/2)[[i]])  ))
    exp <- parse(text=threshold_string)
    title(sub = exp)
    text(x = -1.5, y=8, labels = exp)

          
    
    cat(threshs[[i]],"\n")
    cat("t = ", t_elapsed,'\n')
    cat('\n')
    
    # record time
    times[i,] <- c(threshs[[i]], t_elapsed)
  }
  
  # add pretty fern drawing!
  draw_fern2_pretty(0.01)
  text(x = -2, y = 8, labels = "Just for fun!")
  
  # plot time vs threshold data
  par(mai = c(0.7,0.6,0.4,0.1))
  plot(x=times[,1],y=times[,2], xlab = "Threshold", ylab = "Time to compute", main = "Compute time vs Threshold", log = "xy",xaxt = "n", yaxt = "n")
  
  
  # set ticks
  major.ticks <- (-(n):-1)/2
  labels <- sapply(major.ticks,function(i)
    as.expression(bquote(10^ .(i)))
  )

  axis(1,at=threshs,labels=labels)
  
  major.ticks <- axTicks(2)
  maj <- log10(major.ticks)
  tick_range <- floor(min(maj)):ceiling(max(maj))
  labels <- sapply(tick_range,function(i)
      as.expression(bquote(10^ .(i)))
    )
  axis(2,at=10**(tick_range),labels=labels)
}

