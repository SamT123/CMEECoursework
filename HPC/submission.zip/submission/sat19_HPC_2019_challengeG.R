# CMEE 2019 HPC excercises R code challenge G proforma

rm(list=ls()) # nothing written elsewhere should be needed to make this work

name <- "Sam Turner"
preferred_name <- "Sam"
email <- "sat19@ic.ac.uk"
username <- "sat19"

# I have two solutions:
# 1)  The first produces a fern identical to the ones we produced in the main exercises, except for maybe differing length threshold.
#     This solution is 143 characters long
#
# 2)  The second produces a slightly uglier fern, as I modify numerical constants to reduce character count further
#     This solution is 138 characters long, and pasted below as a comment before the character count starts.
# 
#     f=function(s,d,l,i){e=s+c(cos(d),sin(d))*l;lines(rbind(s,e));if(l>.002){f(e,d,l*.9,-i);f(e,d+i*.8,l*.4,i)}};plot.new();f(c(.5,0),1.6,.1,1)

# I also can shave off a couple of characters with the plot.new() call, but this makes the figure too ugly for me.

# don't worry about comments for this challenge - the number of characters used will be counted starting from here
f=function(s,d,l,i){e=s+c(cos(d),sin(d))*l;lines(rbind(s,e));if(l>.001){f(e,d,l*.87,-i);f(e,d+i*pi/4,l*.38,i)}};plot.new();f(c(.5,0),pi/2,.1,1)