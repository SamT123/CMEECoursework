rm(list=ls()) 
# source main file, containing the cluster run function - which has been copied to TMPDIR in my .sh file
source("sat19_HPC_2019_main.R")

# clear graphics
graphics.off()

# set iteration for this run
iter <- as.numeric(Sys.getenv("PBS_ARRAY_INDEX"))

# set seed
set.seed(iter)

# choose community size
sizes_list <- list(500,1000,2500,5000)
remainder <- iter %% 4 + 1
size <- sizes_list[[remainder]]

# set time to collect data for
hours = 11.5

# create output file name
output_file_name <- paste0('simulation_out_',size,'_',iter,'.rda')

# run simulation
cluster_run(speciation_rate = 0.002005, size=size, wall_time=hours * 60, interval_rich=1, interval_oct=floor(size/10),
            burn_in_generations=8*size, output_file_name=output_file_name) 

